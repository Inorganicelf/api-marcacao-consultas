package com.fiap.eca.api_marcacao_consultas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiMarcacaoConsultasApplicationTests {

	@Test
	void contextLoads() {
	}

}
